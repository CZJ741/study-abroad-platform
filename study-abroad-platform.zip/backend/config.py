# 数据库配置文件
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '2248962829',  # 请修改为您的MySQL密码
    'database': 'study_abroad',
    'charset': 'utf8mb4'
}

# 服务器配置
SERVER_CONFIG = {
    'host': 'localhost',
    'port': 8000,
    'cors_origin': 'http://studyapi.vgit.cn'
}
